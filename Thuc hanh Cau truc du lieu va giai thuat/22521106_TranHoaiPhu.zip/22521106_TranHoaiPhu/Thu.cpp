#include <bits/stdc++.h>
#define fo "bai1.txt"
using namespace std;
int main(){
	freopen(fo,"w",stdout);
	for(int i=0;i<10000;i++){
		for(char letter='a';letter<='z';letter++)
		cout<<letter;
	}
	cout<<endl<<"a";
	return 0;
}
