#pragma once
#include "Quan.h"
#include <iostream>
using namespace std;
class QuanShort:public Quan
{
public:
	QuanShort();
	~QuanShort();
	void Nhap();
};

