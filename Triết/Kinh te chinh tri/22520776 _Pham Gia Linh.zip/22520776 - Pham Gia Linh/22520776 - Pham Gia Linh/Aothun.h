#pragma once
#include "Ao.h"
#include <iostream>
using namespace std;
#include <fstream>
using namespace std;
class Aothun : public Ao
{
public:
	Aothun();
	~Aothun();
	void Nhap();
};

