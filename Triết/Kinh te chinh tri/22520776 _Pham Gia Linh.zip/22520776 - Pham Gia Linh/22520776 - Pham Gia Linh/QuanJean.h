#pragma once
#include "Quan.h"
#include <iostream>
using namespace std;
class QuanJean : public Quan
{
public:
	QuanJean();
	~QuanJean();
};

