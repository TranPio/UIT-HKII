#include "Aothun.h"
using namespace std;
Aothun::Aothun()
{
	loai = 2;
}

Aothun::~Aothun()
{
}

void Aothun::Nhap()
{
	cout << "Nhap don gia ao thun: ";
	cin >> dongia;
}
