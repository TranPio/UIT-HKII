#include<iostream>
#include"congvien.h"
using namespace std;
int main() {
    congvien x;
    x.nhap();
    x.xuat();
    return 0;
}