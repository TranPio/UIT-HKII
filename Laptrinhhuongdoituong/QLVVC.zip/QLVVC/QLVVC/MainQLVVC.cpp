#include<iostream>
#include"Congvien.h"
using namespace std;
int main() {
    Congvien x;
    x.nhap();
    x.xuat();
    return 0;
}