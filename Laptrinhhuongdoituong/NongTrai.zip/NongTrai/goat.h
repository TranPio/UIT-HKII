#pragma once
#include "giasuc.h"
#include <iostream>
using namespace std;
class goat : public giasuc
{
public:
	goat();
	~goat();
	int sinhcon();
	int sua();
	void tiengkeu();
	int getloai();
};

