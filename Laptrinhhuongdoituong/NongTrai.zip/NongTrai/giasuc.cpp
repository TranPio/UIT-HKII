#include "giasuc.h"
#include <iostream>
using namespace std;

giasuc::giasuc()
{
    loai = 0;
}

giasuc::~giasuc()
{
}

int giasuc::sinhcon()
{
    return 0;
}

int giasuc::sua()
{
    return 0;
}

void giasuc::tiengkeu()
{
}

int giasuc::getloai()
{
    return 0;
}
