#include<iostream>
#include"Congty.h"
using namespace std;
int main() {
	Congty x;
	x.nhap();
	x.xuat();
}