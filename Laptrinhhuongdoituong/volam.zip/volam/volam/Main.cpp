#include<iostream>
#include<string>
#include"Volamtruyenki.h"
using namespace std;
int main() {
    Volamtruyenki a;
    a.nhap();
    a.xuat();
    a.satthuongcaonhat();
    a.thuoctinhtancong();
    return 0;
}